# GoldenEye Android

Projeto Android nativo (Java) para servir de frontend ao futuro núcleo recompilado.

## Incluído
- Seletor de ROM por Storage Access Framework
- Permissão persistente de leitura
- Menu principal
- Configurações de resolução, filtro, VSync, FPS, widescreen e desempenho
- Configurações de controles
- Tela preparada para integrar o renderizador/core recompilado
- Preferências salvas no aparelho

## Importante
Este projeto NÃO contém a ROM comercial nem o código/assets proprietários do jogo.
Ele também não é ainda um emulador: o botão JOGAR é uma interface preparada para receber o core recompilado.

## Compilar
Abra a pasta no Android Studio ou em um ambiente Gradle com Android SDK.
Requisitos: JDK 17, Android SDK 35 e Gradle/Android Gradle Plugin compatíveis.
