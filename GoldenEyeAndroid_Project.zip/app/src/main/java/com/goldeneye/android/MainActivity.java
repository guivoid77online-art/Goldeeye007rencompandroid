package com.goldeneye.android;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView romLabel, fpsLabel;
    android.content.SharedPreferences prefs;
    final int PICK_ROM=77;

    int dp(float n){ return (int)(n*getResources().getDisplayMetrics().density+.5f); }
    TextView text(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setPadding(dp(12),dp(8),dp(12),dp(8)); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(15); b.setAllCaps(false); b.setTextColor(Color.WHITE); return b; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b); prefs=getSharedPreferences("settings",0); showHome();
    }
    void base(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(8,8,10));
        setContentView(root);
        TextView title=text("GOLDENEYE 007 • ANDROID",22); title.setTextColor(Color.rgb(255,212,0));
        title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,dp(60)));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(20),dp(8),dp(20),dp(8));
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }
    void showHome(){
        base();
        romLabel=text("ROM: nenhuma selecionada",16); content.addView(romLabel);
        Button choose=btn("📂 Selecionar ROM (.z64 / .n64 / .v64)"); choose.setOnClickListener(v->pickRom()); content.addView(choose);
        Button play=btn("▶  JOGAR"); play.setOnClickListener(v->showGame()); content.addView(play);
        Button graphics=btn("⚙  Configurações gráficas"); graphics.setOnClickListener(v->showGraphics()); content.addView(graphics);
        Button controls=btn("🎮 Controles"); controls.setOnClickListener(v->showControls()); content.addView(controls);
        content.addView(text("\nNúcleo: aguardando recompilação\nA ROM permanece no armazenamento do usuário.",14));
    }
    void pickRom(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        startActivityForResult(i,PICK_ROM);
    }
    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==PICK_ROM && c==RESULT_OK && d!=null){
            Uri u=d.getData(); try{ getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION); }catch(Exception e){}
            prefs.edit().putString("rom",u.toString()).apply(); romLabel.setText("ROM: "+u.getLastPathSegment());
        }
    }
    void showGraphics(){
        base(); content.addView(text("CONFIGURAÇÕES GRÁFICAS",20));
        addSpinner("Resolução interna",new String[]{"1x • N64 original","2x • Alta","3x • Muito alta","4x • Ultra"},prefs.getInt("res",1),v->prefs.edit().putInt("res",v).apply());
        addSpinner("Filtro de textura",new String[]{"Nearest • N64","Bilinear","Sharp"},prefs.getInt("filter",0),v->prefs.edit().putInt("filter",v).apply());
        addSpinner("Sincronização",new String[]{"VSync","Desligada"},prefs.getInt("vsync",0),v->prefs.edit().putInt("vsync",v).apply());
        addSpinner("Limite de FPS",new String[]{"30 FPS","60 FPS","Sem limite"},prefs.getInt("fps",1),v->prefs.edit().putInt("fps",v).apply());
        CheckBox w=new CheckBox(this); w.setText("Widescreen 16:9"); w.setTextColor(Color.WHITE); w.setChecked(prefs.getBoolean("wide",true)); w.setOnCheckedChangeListener((x,z)->prefs.edit().putBoolean("wide",z).apply()); content.addView(w);
        CheckBox p=new CheckBox(this); p.setText("Modo desempenho"); p.setTextColor(Color.WHITE); p.setChecked(prefs.getBoolean("perf",true)); p.setOnCheckedChangeListener((x,z)->prefs.edit().putBoolean("perf",z).apply()); content.addView(p);
        Button back=btn("← Voltar"); back.setOnClickListener(v->showHome()); content.addView(back);
    }
    interface SaveInt{void go(int x);}
    void addSpinner(String title,String[] a,int sel,SaveInt save){
        content.addView(text(title,15)); Spinner s=new Spinner(this); ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a); s.setAdapter(ad); s.setSelection(sel); s.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> x){} public void onItemSelected(android.widget.AdapterView<?> x,View v,int p,long id){save.go(p);}}); content.addView(s);
    }
    void showControls(){
        base(); content.addView(text("CONTROLES TOUCH",20));
        content.addView(text("Analógico esquerdo: movimento\nAnalógico direito: câmera\nA: ação/interação   B: mirar/voltar\nR: recarregar   Z: mirar\nD-pad: navegação",16));
        addSpinner("Layout",new String[]{"Clássico","Compacto","Grande"},prefs.getInt("layout",0),v->prefs.edit().putInt("layout",v).apply());
        Button back=btn("← Voltar"); back.setOnClickListener(v->showHome()); content.addView(back);
    }
    void showGame(){
        base(); content.addView(text("TELA DE JOGO",20));
        TextView status=text("Núcleo recompilado ainda não conectado.\n\nQuando o core Android for adicionado, esta tela será substituída pelo renderizador.",16);
        content.addView(status);
        Button back=btn("⏸ Menu / Pausar"); back.setOnClickListener(v->showHome()); content.addView(back);
    }
}